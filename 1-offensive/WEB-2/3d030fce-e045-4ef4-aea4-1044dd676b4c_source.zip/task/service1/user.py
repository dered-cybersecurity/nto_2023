from psycopg import DatabaseError
from base64 import b64encode, b64decode
from db import cur,conn
from flask_login import UserMixin
import hashlib

def hash(s: str):
    return hashlib.sha256(s.encode()).hexdigest()


class User(UserMixin):
    id: int
    username: str
    password: str

    def __init__(self, id, username, password):
        self.id = id
        self.username = username 
        self.password = password
    
    @staticmethod
    def get_by_id(id: int):
        try:
            cur.execute("SELECT * FROM users WHERE id=%s;", (id,))
            res = cur.fetchone()
            if not res:
                return
            return User(*res)
        except DatabaseError:
            conn.commit()

    @staticmethod
    def get_by_username(username: str):
        try:
            cur.execute("SELECT * FROM users WHERE username=%s;", (username,))
            res = cur.fetchone()
            if not res:
                return
            return User(*res)
        except DatabaseError:
            conn.commit()

    @staticmethod
    def auth(username: str, password: str):
        try:
            hashed_password = hash(password)
            cur.execute("SELECT * FROM users WHERE username=%s AND password=%s;", (username, hashed_password,))
            res = cur.fetchone()
            if not res:
                return
            return User(*res)
        except DatabaseError:
            conn.commit()

    @staticmethod
    def register(username: str, password: str):
        user = User.get_by_username(username)
        if user:
            return 
        try:
            hashed_password = hash(password)
            cur.execute("INSERT INTO users VALUES (DEFAULT, %s, %s) RETURNING id, username, password;", (username, hashed_password))
            conn.commit()
            res = cur.fetchone()
            if not res:
                return
            return User(*res)
        except DatabaseError:
            conn.commit()
